#include<stdio.h>
#include<stdlib.h>
#include<omp.h>
void initVectors(double *A,double *B,double *C,double *D, double N)
{
for(int i = 0; i < N; i++)
{
A[i] = 1.0;
B[i] = 2.0;
C[i] = 0.0;
D[i] = 0.0;}
}
int min(int a, int b)
{
if(a > b)
{
return a;
}else{
return b;
}
}
int main()
{
int i,N = 1000;
double A[1000];
double B[1000];
double C[1000]; // Output vector to store Parallel results
double D[1000];
//Initialize vectors//
initVectors(A,B,C,D,N);
/****** Parallel Execution ***********/
int nThreads = 8;
omp_set_num_threads(nThreads);
int chunkSize = N/nThreads;
#pragma omp parallel
{
int tid = omp_get_thread_num();
int lower = tid*chunkSize;
int upper = (tid + 1)*chunkSize;
for(int i = tid; i < min(upper,N); i++)
{
C[i] = A[i] + B[i];
}
for(int i = tid; i < min(upper,N); i++)
{
D[i] = A[i] + D[i];
}
}
for(int i = 0; i < N; i++)
{
printf("C[%d] = %f",i,C[i]);
}
return 0;
}
