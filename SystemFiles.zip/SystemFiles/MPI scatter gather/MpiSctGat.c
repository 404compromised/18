#include "mpi.h"      
#include <stdio.h>    
#include <stdlib.h>   

#define MASTER 0         
#define ARRAY_SIZE 8     

int main (int argc, char *argv[])
{
	int * a;
	int * b;
	int * c;
	
	int total_proc;		
	int rank;        
	int n_per_proc;		
	int n = ARRAY_SIZE;   
	int i;       
		
	MPI_Status status;   
	
	MPI_Init (&argc, &argv);
	MPI_Comm_size (MPI_COMM_WORLD, &total_proc);
	MPI_Comm_rank (MPI_COMM_WORLD,&rank);
	
    	int * ap;
	int * bp;
	int * cp;
	
	if (rank == MASTER)  {
		a = (int *) malloc(sizeof(int)*n);
		b = (int *) malloc(sizeof(int)*n);
		c = (int *) malloc(sizeof(int)*n);
		
		for(i=0;i<n;i++)
			a[i] = i;
		for(i=0;i<n;i++)
			b[i] = i;
	}
	
	n_per_proc = n/total_proc;
	
	ap = (int *) malloc(sizeof(int)*n_per_proc);
	bp = (int *) malloc(sizeof(int)*n_per_proc);
	cp = (int *) malloc(sizeof(int)*n_per_proc);
	
	MPI_Scatter(a, n_per_proc, MPI_INT, ap, n_per_proc, MPI_INT, MASTER, MPI_COMM_WORLD);
	//scattering array b from MASTER node out to the other node
	MPI_Scatter(b, n_per_proc, MPI_INT, bp, n_per_proc, MPI_INT, MASTER, MPI_COMM_WORLD);
	
	for(i=0;i<n_per_proc;i++)
		cp[i] = ap[i]+bp[i];
	
	MPI_Gather(cp, n_per_proc, MPI_INT, c, n_per_proc, MPI_INT, MASTER, MPI_COMM_WORLD);
	if (rank == MASTER)  {			
	
		int good = 1;
		for(i=0;i<n;i++) {
			if (c[i] != a[i] + b[i]) {
				printf("problem at index %lld\n", (long long int)1);
				good = 0;
				break;
			}
		}
		if (good) {
			printf ("Values correct!\n");
		}
		
	}


	if (rank == MASTER)  {
		free(a);  free(b); free(c);
	}
	free(ap);  free(bp); free(cp);
	
	
	MPI_Finalize();  
	
	return 0;
}
