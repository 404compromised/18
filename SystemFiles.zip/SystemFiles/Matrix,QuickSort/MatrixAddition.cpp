#include<stdio.h>
int main()
{
int i,j,n;
printf("\nEnter the size size of square matrix : ");
scanf("%d",&n);
int a[n][n],b[n][n],c[n][n];
for(i=0;i<n;i++)
{
for(j=0;j<n;j++)
{
a[i][j]=i+j;
b[i][j]=i+j*2;
}
}
printf("\nThe two arrays are : \n");
for(i=0;i<n;i++)
{
for(j=0;j<n;j++)
{
printf("\t%d",a[i][j]);
}
printf("\n");
}
printf("\n\n");
for(i=0;i<n;i++)
{
for(j=0;j<n;j++)
{
printf("\t%d",b[i][j]);
}
printf("\n");
}
for(i=0;i<n;i++)
{
for(j=0;j<n;j++)
{
c[i][j]=a[i][j]+b[i][j];
}
}
printf("\nAddition of two matrices : \n");
for(i=0;i<n;i++)
{
for(j=0;j<n;j++)
{
printf("\t%d",c[i][j]);
}
printf("\n");
}
return 0;
}
